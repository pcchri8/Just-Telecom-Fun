clc;
clear;
close all;

%% Parameters
lambda = 0.03; 
Delta_t = lambda/2; 
Delta_r = lambda/2; 
d = 4;

SNR_dB = -20:5:40;
SNR = 10.^(SNR_dB/10);

kappa_dB = [0 10 100];
kappa_vec = 10.^(kappa_dB/10);

Nreal = 500;

configs = [4 4];         % MIMO configuration(s)
cfg_names = {'4x4'};

%% Antenna positions (ULA)
Nt_max = max(configs(:,1));
Nr_max = max(configs(:,2));

tx_pos = (0:Nt_max-1)*Delta_t;
rx_pos = (0:Nr_max-1)*Delta_r;

%% Main loop
for cfg = 1:size(configs,1)

    Nt = configs(cfg,1);
    Nr = configs(cfg,2);

    figure; hold on; grid on;

    for kk = 1:length(kappa_vec)

        kappa = kappa_vec(kk);

        ratio_mmse = zeros(size(SNR));
        ratio_sic  = zeros(size(SNR));

        for s = 1:length(SNR)

            rho = SNR(s);
            Rmmse_sum = 0;
            Rsic_sum  = 0;

            for mc = 1:Nreal

                %% LOS component
                H_LOS = zeros(Nr,Nt);
                for i = 1:Nr
                    for j = 1:Nt
                        dij = sqrt(d^2 + (rx_pos(i)-tx_pos(j))^2);
                        H_LOS(i,j) = (1/dij) * exp(-1j*2*pi*dij/lambda);
                    end
                end

                %% NLOS component
                H_NLOS = (randn(Nr,Nt) + 1j*randn(Nr,Nt))/sqrt(2);

                %% Rician channel
                H = sqrt(1/(kappa+1))*H_NLOS + sqrt(kappa/(kappa+1))*H_LOS;

                %% ============================
                % 1) MMSE
                %% ============================
                A = inv( eye(Nt) + (rho/Nt)*(H'*H) );
                gamma_mmse = 1./real(diag(A)) - 1;
                Rmmse_sum = Rmmse_sum + sum(log2(1 + gamma_mmse));

                %% ============================
                % 2) MMSE-SIC
                %% ============================
                Hsic = H;
                Rsic = 0;

                for layer = 1:Nt
                    Asic = inv( eye(size(Hsic,2)) + (rho/Nt)*(Hsic'*Hsic) );
                    gamma_sic = 1./real(diag(Asic)) - 1;

                    [gmax, idx] = max(gamma_sic);
                    Rsic = Rsic + log2(1 + gmax);

                    Hsic(:,idx) = [];
                    if isempty(Hsic)
                        break;
                    end
                end

                Rsic_sum = Rsic_sum + Rsic;

            end

            ratio_mmse(s) = Rmmse_sum / Nreal;
            ratio_sic(s)  = Rsic_sum  / Nreal;

        end

        %% Plot for this kappa
        plot(SNR_dB, ratio_sic, 'LineWidth', 2, ...
            'DisplayName', ['SIC, \kappa=', num2str(10*log10(kappa))]);
        plot(SNR_dB, ratio_mmse, '--', 'LineWidth', 2, ...
            'DisplayName', ['MMSE, \kappa=', num2str(10*log10(kappa))]);

    end

    xlabel('SNR (dB)');
    ylabel('Ergodic Rate (bits/s/Hz)');
    title(['MIMO ', cfg_names{cfg}]);
    legend('Location','best');
    grid on;

end
