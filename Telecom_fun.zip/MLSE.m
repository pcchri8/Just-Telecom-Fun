% ================================================================
% MLSE using Viterbi Algorithm
% Correct implementation for ISI channels
% ================================================================

clear;
close all;
clc;

%% Parameters

N = 500;              % Symbols per block
L = 3;                 % Channel taps
T = 100;               % Monte Carlo blocks

SNR_dB = 0:15;

%% QPSK alphabet

A = (1/sqrt(2))* ...
    [1+1i;
    -1+1i;
     1-1i;
    -1-1i];

M = length(A);

%% Trellis states

memory = L - 1;

numStates = M^memory;

%% BER vectors

BER_mlse  = zeros(size(SNR_dB)); %bit error rate for MLSE 
BER_ideal = zeros(size(SNR_dB)); %bit error rate for isi-free

%% ================================================================
% SNR LOOP
% ================================================================

for snrIdx = 1:length(SNR_dB)

    SNR = SNR_dB(snrIdx);

    N0 = 10^(-SNR/10);

    rng(1);

    %% Fixed channel

    h = (1/sqrt(2))* ...
        (randn(L,1) + 1i*randn(L,1));

    BERtmp_mlse  = zeros(T,1);
    BERtmp_ideal = zeros(T,1);

    %% ============================================================
    % BLOCK LOOP
    % ============================================================

    for t = 1:T

        %% Transmit sequence

        [X,B] = txSeq(N,'QPSK');

        %% Channel

        Yclean = conv(X,h); %noise-free received symbol

        W = sqrt(N0/2)* ...
            (randn(length(Yclean),1) + ...
             1i*randn(length(Yclean),1)); %AWGN term

        Y = Yclean + W; %received symbol with noise

        %% ========================================================
        % TRELLIS STATES
        % ========================================================

        % Each state stores:
        %
        % [x(k-1), x(k-2), ..., x(k-L+1)]

        stateSymbols = zeros(numStates,memory);

        cnt = 1;

        if memory == 2

            for a = 1:M
                for b = 1:M

                    stateSymbols(cnt,:) = ...
                        [A(a), A(b)];

                    cnt = cnt + 1;

                end
            end

        elseif memory == 1

            for a = 1:M

                stateSymbols(cnt,:) = A(a);

                cnt = cnt + 1;

            end

        end

        %% ========================================================
        % INITIALIZATION
        % ========================================================

        pathMetric = inf(numStates,N+1);

        survivorState  = zeros(numStates,N);
        survivorSymbol = zeros(numStates,N);

        % Start from zero-memory state
        %
        % Assume previous symbols are zeros

        zeroState = 1;

        pathMetric(zeroState,1) = 0;

        %% ========================================================
        % VITERBI RECURSION
        % ========================================================

        for k = 1:N

            for prevState = 1:numStates

                prevMetric = pathMetric(prevState,k);

                if isinf(prevMetric)
                    continue;
                end

                prevSymbols = stateSymbols(prevState,:);

                %% Try all possible new symbols

                for inputIdx = 1:M

                    xk = A(inputIdx);

                    %% Construct symbol vector
                    %
                    % [x(k), x(k-1), x(k-2)]

                    xVec = [xk; prevSymbols(:)];

                    %% Expected received sample

                    yHat = h.' * xVec;

                    %% Actual received sample

                    yk = Y(k);

                    %% Branch metric

                    branchMetric = abs(yk - yHat)^2;

                    %% Next state
                    %
                    % Shift register update

                    if memory > 1

                        nextMemory = ...
                            [xk, prevSymbols(1:end-1)];

                    else

                        nextMemory = xk;

                    end

                    %% Find next state index

                    nextState = 1;

                    for s = 1:numStates

                        if isequal(stateSymbols(s,:),nextMemory)

                            nextState = s;
                            break;

                        end
                    end

                    %% Metric update

                    newMetric = ...
                        prevMetric + branchMetric;

                    if newMetric < ...
                            pathMetric(nextState,k+1)

                        pathMetric(nextState,k+1) = ...
                            newMetric;

                        survivorState(nextState,k) = ...
                            prevState;

                        survivorSymbol(nextState,k) = ...
                            inputIdx;

                    end

                end
            end
        end

        %% ========================================================
        % TRACEBACK
        % ========================================================

        Xhat = zeros(N,1);

        [~,state] = min(pathMetric(:,N+1));

        for k = N:-1:1

            inputIdx = survivorSymbol(state,k);

            Xhat(k) = A(inputIdx);

            state = survivorState(state,k);

        end

        %% ========================================================
        % BER
        % ========================================================

        Bhat = rxSeq(Xhat,'QPSK');

        BERtmp_mlse(t) = ...
            sum(abs(B - Bhat))/length(B);

        %% ========================================================
        % IDEAL ISI-FREE REFERENCE
        % ========================================================

        H = convmtx(h,N);

        X2 = zeros(N,1);

        for n = 1:N

            delays = find(H(:,n) ~= 0);

            X2(n) = ...
                (1/norm(H(delays,n),2))* ...
                (H(delays,n)'*H(delays,n)*X(n) ...
                + H(delays,n)'*W(delays));

        end

        Bideal = rxSeq(X2,'QPSK');

        BERtmp_ideal(t) = ...
            sum(abs(B - Bideal))/length(B);

    end

    %% Average BER

    BER_mlse(snrIdx)  = mean(BERtmp_mlse);
    BER_ideal(snrIdx) = mean(BERtmp_ideal);

end

%% ================================================================
% PLOTS
% ================================================================

figure;

semilogy(SNR_dB,BER_mlse,'-o','LineWidth',2);
hold on;

semilogy(SNR_dB,BER_ideal,'-k','LineWidth',2);

grid on;

xlabel('SNR (dB)');
ylabel('BER');

legend('MLSE (Viterbi)','ISI-free');

title('MLSE using Viterbi Algorithm');

ylim([1e-4 1]);