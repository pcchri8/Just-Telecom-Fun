clc;
clear;
close all;

%% Parameters

SNR_dB = -20:5:40; %SNR dB
SNR = 10.^(SNR_dB/10); %SNR real number

Nreal = 500; %number of realizations

configs = [
    8 8;
    4 8;
    4 4
]; %MIMO antenna configurations

cfg_names = {'8x8','4x8','4x4'};

%% Main loop

for cfg = 1:size(configs,1)

    Nt = configs(cfg,1); %number of antennas Tx
    Nr = configs(cfg,2); %number of antennas Rx
    
    %preallocation
    ratio_mf   = zeros(size(SNR)); %matched filter
    ratio_zf   = zeros(size(SNR)); %zero forcing
    ratio_mmse = zeros(size(SNR)); %mmse
    ratio_sic  = zeros(size(SNR)); %sic

    % SNR loop

    for s = 1:length(SNR)

        rho = SNR(s);
        
        %sum rates of all the trials of an SNR level pre-allocation
        Csum = 0;

        Rmf_sum   = 0;
        Rzf_sum   = 0;
        Rmmse_sum = 0;
        Rsic_sum  = 0;

        % Monte-Carlo
        
        for mc = 1:Nreal

            % Rayleigh channel

            H = (randn(Nr,Nt) + 1j*randn(Nr,Nt))/sqrt(2);

            % Capacity
            C = real(log2(det( eye(Nr) + (rho/Nt)*(H*H') )));

            Csum = Csum + C;

           %% =================================================
           % 1) Matched Filter
           %% =================================================

           Rmf = 0;

           for k = 1:Nt

               hk = H(:,k);
               signal_power = (rho/Nt) * abs(hk' * hk)^2;
               interference_power = 0;

               for j = 1:Nt
                   if j ~= k
            
                       hj = H(:,j);           
                       interference_power = interference_power + ...
                           (rho/Nt) * abs(hk' * hj)^2;

                   end
               end

               noise_power = norm(hk)^2;
               gamma_mf = signal_power / (interference_power + noise_power);
               Rmf = Rmf + log2(1 + gamma_mf);

           end

           Rmf_sum = Rmf_sum + Rmf;

            %% =================================================
            % 2) ZF / Decorrelator
            %% =================================================

            G = inv(H'*H);

            gamma_zf = zeros(Nt,1);

            for k = 1:Nt

                gamma_zf(k) = ...
                    (rho/Nt)/real(G(k,k));

            end

            Rzf = sum(log2(1 + gamma_zf));

            Rzf_sum = Rzf_sum + Rzf;

            %% =================================================
            % 3) MMSE
            %% =================================================

            A = inv( eye(Nt) + ...
                (rho/Nt)*(H'*H) );

            gamma_mmse = zeros(Nt,1);

            for k = 1:Nt

                gamma_mmse(k) = ...
                    1/real(A(k,k)) - 1;

            end

            Rmmse = sum(log2(1 + gamma_mmse));

            Rmmse_sum = Rmmse_sum + Rmmse;

            %% =================================================
            % 4) MMSE-SIC
            %% =================================================

            Hsic = H;

            Rsic = 0;

            for layer = 1:Nt

                Asic = inv( eye(size(Hsic,2)) + ...
                    (rho/Nt)*(Hsic'*Hsic) );

                gamma_sic = zeros(size(Hsic,2),1);

                for k = 1:length(gamma_sic)

                    gamma_sic(k) = ...
                        1/real(Asic(k,k)) - 1;

                end

                [gmax, idx] = max(gamma_sic);

                Rsic = Rsic + log2(1 + gmax);

                Hsic(:,idx) = [];

                if isempty(Hsic)
                    break;
                end

            end

            Rsic_sum = Rsic_sum + Rsic;

        end

        %% ====================================================
        % Ratios
        %% ====================================================

        Cerg = Csum/Nreal; %estimated ergodic capacity

        ratio_mf(s)   = Rmf_sum/(Nreal*Cerg);
        ratio_zf(s)   = Rzf_sum/(Nreal*Cerg);
        ratio_mmse(s) = Rmmse_sum/(Nreal*Cerg);
        ratio_sic(s)  = Rsic_sum/(Nreal*Cerg);

    end

    %% Plot

    figure;

    plot(SNR_dB, ratio_sic, 'LineWidth',2);
    hold on;

    plot(SNR_dB, ratio_mmse, '--', 'LineWidth',2);

    plot(SNR_dB, ratio_mf, ':', 'LineWidth',2);

    plot(SNR_dB, ratio_zf, '-.', 'LineWidth',2);

    grid on;

    xlabel('SNR (dB)');
    ylabel(['R / C_{',num2str(Nt),num2str(Nr),'}']);

    ylim([0 1.05]);

    title(['MIMO ', cfg_names{cfg}]);

    legend('MMSE-SIC','MMSE', ...
        'Matched Filter','Decorrelator', ...
        'Location','best');

end