% Function for generating random symbol sequence and its binary
% sequence.
% Inputs:   N = symbol sequence length
%           mod = modulation type
% Outputs:  X = symbol sequence
%           B = binary sequence
function [X, B] = txSeq(N,mod)
if strcmp(mod, 'BPSK')
    % BPSK symbol sequence
    X = randi([1 2],N,1);
    X(X == 1) = 1;
    X(X == 2) = -1;

    % Binary sequence for BER calculation
    B = [];
    for ii = 1:N
        if sign(X(ii)) == 1
            B = [B 1]; % X = 1 --> B = 1
        else
            B = [B 0]; % X = -1 --> B = 0
        end
    end


elseif strcmp(mod, 'QPSK')
    % QPSK symbol sequence
    X = randi([1 4],N,1);
    X(X == 1) = 1 + 1i;
    X(X == 2) = -1 + 1i;
    X(X == 3) = 1 - 1i;
    X(X == 4) = -1 - 1i;
    X = (1/sqrt(2))*X;

    % Binary sequence for BER calculation (Gray-coded)
    B = [];
    for ii = 1:N
        if sign(real(X(ii))) == 1
            if sign(imag(X(ii))) == 1
                B = [B 0 0]; % 1 + 1i --> 00 
            else
                B = [B 0 1]; % 1 - 1i --> 01
            end
        else
            if sign(imag(X(ii))) == 1
                B = [B 1 0]; % -1 + 1i --> 10
            else
                B = [B 1 1]; % -1 - 1i --> 11
            end
        end
    end
end
end