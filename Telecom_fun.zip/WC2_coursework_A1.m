clc;
clear;
close all;

%% Parameters

nt = 64;
nr = 64;

lambda = 0.03;             
Delta_t = lambda/2;
Delta_r = lambda/2;

d_vec = 3:20;              

SNR_dB = 10;
rho = 10^(SNR_dB/10);

capacity_exact = zeros(length(d_vec),1);
capacity_farfield = zeros(length(d_vec),1);

%% Antenna coordinates

tx_pos = (0:nt-1) * Delta_t;
rx_pos = (0:nr-1) * Delta_r;

%% Main loop

for idx = 1:length(d_vec)

    d = d_vec(idx);

    %% ============================================================
    % Exact spherical-wave LoS channel
    %% ============================================================

    H_exact = zeros(nr,nt);

    for i = 1:nr
        for j = 1:nt

            dij = sqrt(d^2 + (rx_pos(i)-tx_pos(j))^2);

            H_exact(i,j) = (1/d) * ...
                exp(-1j*2*pi*dij/lambda);

        end
    end

    %% ============================================================
    % Far-field LoS approximation
    %% ============================================================

    H_ff = (1/d) * exp(-1j*2*pi*d/lambda) * ones(nr,nt);

    %% ============================================================
    % Capacity calculations
    %% ============================================================

    C_exact = log2(det( eye(nr) + ...
              (rho/nt)*(H_exact*H_exact') ));

    C_ff = log2(det( eye(nr) + ...
           (rho/nt)*(H_ff*H_ff') ));

    capacity_exact(idx) = real(C_exact);
    capacity_farfield(idx) = real(C_ff);

end

%% ================================================================
% Plot
%% ================================================================

figure;

plot(d_vec, capacity_exact, ...
    'LineWidth',2);
hold on;

plot(d_vec, capacity_farfield, '--', ...
    'LineWidth',2);

xlabel('Distance d (m)');
ylabel('Capacity (bits/s/Hz)');

title('LoS MIMO Capacity');

legend('Exact spherical-wave', ...
       'Far-field approximation');

grid on;