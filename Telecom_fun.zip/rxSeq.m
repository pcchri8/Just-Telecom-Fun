% Convert received symbols into bit sequence
function [B] = rxSeq(X,mod)
N = length(X);
B = [];
if strcmp(mod,'BPSK')
    for ii = 1:N
        if sign(real(X(ii))) == 1
            B = [B 1]; % X = 1 --> B = 1
        else
            B = [B 0]; % X = -1 --> B = 0
        end
    end
elseif strcmp(mod,'QPSK')
    for ii = 1:N
        if sign(real(X(ii))) == 1
            if sign(imag(X(ii))) == 1
                B = [B 0 0]; % 1 + 1i --> 00 
            else
                B = [B 0 1]; % 1 - 1i --> 01
            end
        else
            if sign(imag(X(ii))) == 1
                B = [B 1 0]; % -1 + 1i --> 10
            else
                B = [B 1 1]; % -1 - 1i --> 11
            end
        end
    end
end