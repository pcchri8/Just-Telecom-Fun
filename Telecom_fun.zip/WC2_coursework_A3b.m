clc; clear; close all;

%% Parameters

lambda = 0.03;
Delta_t = lambda/2;
Delta_r = lambda/2;
d = 4;

SNR_dB_vec = [15 25];
SNR_vec = 10.^(SNR_dB_vec/10);

kappa_dB = 0:5:100;
kappa_vec = 10.^(kappa_dB/10);

Nreal = 300;

configs = [4 4; 8 4];
cfg_names = {'4x4','8x4'};

%% Antenna positions
Nt_max = max(configs(:,1));
Nr_max = max(configs(:,2));

tx_pos = (0:Nt_max-1)*Delta_t;
rx_pos = (0:Nr_max-1)*Delta_r;

%% Define colors for streams (Ns = 1,2,3,4,...)
stream_colors = lines(Nt_max);   

%% Loop over MIMO configs
for cfg = 1:size(configs,1)

    Nt = configs(cfg,1);
    Nr = configs(cfg,2);

    Ns_vec = 1:Nt;   % number of active streams

    figure; hold on; grid on;

    for ss = 1:length(SNR_vec)

        rho = SNR_vec(ss);

        C = zeros(length(Ns_vec), length(kappa_vec));

        for kk = 1:length(kappa_vec)

            kappa = kappa_vec(kk);

            Ctemp = zeros(length(Ns_vec),1);

            for mc = 1:Nreal

                %% Build Rician channel
                H_LOS = zeros(Nr,Nt);
                for i = 1:Nr
                    for j = 1:Nt
                        dij = sqrt(d^2 + (rx_pos(i)-tx_pos(j))^2);
                        H_LOS(i,j) = (1/dij)*exp(-1j*2*pi*dij/lambda);
                    end
                end

                H_NLOS = (randn(Nr,Nt)+1j*randn(Nr,Nt))/sqrt(2);
                H = sqrt(1/(kappa+1))*H_NLOS + sqrt(kappa/(kappa+1))*H_LOS;

                %% Loop over number of streams
                for ns = 1:length(Ns_vec)

                    Ns = Ns_vec(ns);

                    % Select best Ns transmit antennas (max Frobenius norm)
                    norms = vecnorm(H,2,1);
                    [~, idx] = maxk(norms, Ns);
                    Hs = H(:, idx);

                    % MMSE-SIC
                    Rsic = 0;
                    Hsic = Hs;

                    for layer = 1:Ns
                        Asic = inv( eye(size(Hsic,2)) + ...
                            (rho/Ns)*(Hsic'*Hsic) );

                        gamma_sic = 1./real(diag(Asic)) - 1;

                        [gmax, id] = max(gamma_sic);
                        Rsic = Rsic + log2(1 + gmax);

                        Hsic(:,id) = [];
                        if isempty(Hsic), break; end
                    end

                    Ctemp(ns) = Ctemp(ns) + Rsic;

                end
            end

            C(:,kk) = Ctemp / Nreal;

        end

        %% Plot for this SNR
        for ns = 1:length(Ns_vec)

            % Solid for 25 dB, dashed for 15 dB
            if SNR_dB_vec(ss) == 25
                style = '-';
            else
                style = '--';
            end

            plot(kappa_dB, C(ns,:), ...
                'Color', stream_colors(ns,:), ...
                'LineStyle', style, ...
                'LineWidth', 1.2, ...
                'DisplayName', ...
                [cfg_names{cfg}, ', Ns=', num2str(Ns_vec(ns)), ...
                 ', SNR=', num2str(SNR_dB_vec(ss)), ' dB']);
        end

    end

    xlabel('Rice factor \kappa (dB)');
    ylabel('Achievable Rate (bits/s/Hz)');
    title(['Capacity vs \kappa for ', cfg_names{cfg}]);
    legend('Location','bestoutside');
    grid on;

end
