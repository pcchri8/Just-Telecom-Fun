% Wireless Communications 2 Course Work part B - Equalizers under fixed 
% channels

clear all;
close all;
clc;

%% Parameter values
N = 500;              % Block length
L = 3;                % Channel taps
SNR_dB = 0:1:15;      % SNR range
T = 100;              % Blocks of N symbols 

%% Inputs
S = 50;                % Number of received samples

%% SNR-loop
idx = 0;

for SNR_lin = SNR_dB

    idx = idx + 1;

    % Same channel/noise realization for fairness
    rng(1);

    % Noise variance (the formula simplifies because the transmitted symbol is normalized)
    N0 = 10^(-SNR_lin/10);

    %% Channel
    % Channel taps
    h = (1/sqrt(2))*(randn(L,1) + 1i*randn(L,1));

    % Convolution matrix
    H = convmtx(h,N);

    for t = 1:T %for each block of symbols

        disp(['SNR = ',num2str(SNR_lin), ...
              ' | t = ',num2str(t), ...
              ' | S = ',num2str(S)])

        %% QPSK transmission
        [X,B] = txSeq(N,'QPSK');

        %% Received signal
        W = sqrt(N0/2)*(randn(N+L-1,1) + 1i*randn(N+L-1,1));

        Y = H*X + W;

        %% ============================================================
        % TRAINING
        % =============================================================
        if t == 1 %first block used to train equalizers

            % Pre-allocation in cells (using cells because of difference in dimensionality)
            c_lmmse = cell(N,1);
            c_zf_dfe = cell(N,1);
            c_lmmse_dfe = cell(N,1);

            for m = 1:N %for each symbol in a certain block

                [sampleWindow, includedSignals] = ...
                    windowing(m,S,N,L);

                % Received vector
                r = Y(sampleWindow);

                % Desired symbol index inside included signals
                targetIdx = find(includedSignals == m);

                % Effective channel matrix
                H_eff = H(sampleWindow,includedSignals);

                % Desired channel vector
                p = H_eff(:,targetIdx);

                %% ----------------------------------------------------
                % Symbol-wise LMMSE
                % -----------------------------------------------------
                R = H_eff*H_eff' + N0*eye(length(sampleWindow));
                c_lmmse{m} = R \ p;

                %% ----------------------------------------------------
                % DIRECT FEED EQUALIZATION
                % ZF-DFE AND LMMSE-DFE
                % -----------------------------------------------------
               
                futureCols = (targetIdx+1):size(H_eff,2);

                if isempty(futureCols)

                    A = p;

                else

                    A = [p H_eff(:,futureCols)];

                end

                % ZF-DFE
                e1 = zeros(size(A,2),1);
                e1(1) = 1;
                c_zf_dfe{m} = A*((A'*A)\e1);
                c_zf_dfe{m} = c_zf_dfe{m}/(c_zf_dfe{m}'*p);

                g = c_zf_dfe{m}' * A;
                disp(g);

                % LMMSE-DFE
                c_lmmse_dfe{m} = (A*A' + N0*eye(size(A,1))) \ p;
            end

            %% ========================================================
            % Least Squares Equalizer
            % =========================================================
            R_hat = 0;
            p_hat = 0;

            % Only use full windows
            range = ceil(S/2):N-floor(S/2);

            for m = range

                [sampleWindow, includedSignals] = ...
                    windowing(m,S,N,L);

                r = Y(sampleWindow);

                R_hat = R_hat + r*r';

                p_hat = p_hat + r*conj(X(m));

            end

            R_hat = R_hat/length(range);
            p_hat = p_hat/length(range);

            c_ls = R_hat \ p_hat;

        end

        %% ============================================================
        % EQUALIZATION
        % =============================================================

        X_lmmse = zeros(N,1);
        X_ls = zeros(N,1);
        X_zf_dfe = zeros(N,1);
        X_lmmse_dfe = zeros(N,1);

        for m = 1:N

            [sampleWindow, includedSignals] = ...
                windowing(m,S,N,L);

            %% --------------------------------------------------------
            % LMMSE
            % ---------------------------------------------------------
            r = Y(sampleWindow);

            X_lmmse(m) = c_lmmse{m}' * r;

            %% --------------------------------------------------------
            % Least Squares
            % ---------------------------------------------------------
            r_ls = zeros(S,1);

            len = min(length(r),S);

            r_ls(1:len) = r(1:len);

            X_ls(m) = c_ls' * r_ls;

            %% --------------------------------------------------------
            % DFE-ZF
            % ---------------------------------------------------------
            H_eff = H(sampleWindow,includedSignals);

            targetIdx = find(includedSignals == m);

            p = H_eff(:,targetIdx);

            % Past symbols
            pastIdx = includedSignals(includedSignals < m);

            r_dfe = r;

            % Cancel already detected symbols
            for k = 1:length(pastIdx)

                idxPast = pastIdx(k);

                localIdx = find(includedSignals == idxPast);

                r_dfe = r_dfe - ...
                    H_eff(:,localIdx)*X_zf_dfe(idxPast);

            end

            X_zf_dfe(m) = c_zf_dfe{m}' * r_dfe;

           %% Hard decision (QPSK slicer)

           tmp = X_zf_dfe(m);

           if real(tmp) >= 0
               re = 1;
           else
               re = -1;
           end

           if imag(tmp) >= 0
               im = 1;
           else
               im = -1;
           end

           X_zf_dfe(m) = (re + 1i*im)/sqrt(2);

            %% --------------------------------------------------------
            % DFE-LMMSE
            % ---------------------------------------------------------
            r_dfe2 = r;

            for k = 1:length(pastIdx)

                idxPast = pastIdx(k);

                localIdx = find(includedSignals == idxPast);

                r_dfe2 = r_dfe2 - ...
                    H_eff(:,localIdx)*X_lmmse_dfe(idxPast);

            end

            X_lmmse_dfe(m) = c_lmmse_dfe{m}' * r_dfe2;

            %% Hard decision (QPSK slicer)

            tmp = X_lmmse_dfe(m);

            if real(tmp) >= 0
                re = 1;
            else
                re = -1;
            end

            if imag(tmp) >= 0
                im = 1;
            else
                im = -1;
            end

            X_lmmse_dfe(m) = (re + 1i*im)/sqrt(2);

        end

        %% ============================================================
        % SYMBOL DETECTION
        % =============================================================

        % LMMSE
        B_lmmse = rxSeq(X_lmmse,'QPSK');
        BER_lmmse_tmp(t,idx) = ...
            sum(abs(B - B_lmmse))/length(B);

        % LS
        B_ls = rxSeq(X_ls,'QPSK');
        BER_ls_tmp(t,idx) = ...
            sum(abs(B - B_ls))/length(B);

        % DFE-ZF
        B_zf_dfe = rxSeq(X_zf_dfe,'QPSK');
        BER_zf_dfe_temp(t,idx) = ...
            sum(abs(B - B_zf_dfe))/length(B);

        % DFE-LMMSE
        B_lmmse_dfe = rxSeq(X_lmmse_dfe,'QPSK');
        BER_lmmse_dfe_temp(t,idx) = ...
            sum(abs(B - B_lmmse_dfe))/length(B);

        %% Ideal ISI-free reference
        X2 = zeros(N,1);

        for n = 1:N

            delays = find(H(:,n) ~= 0);

            X2(n) = ...
                (1/norm(H(delays,n),2))* ...
                (H(delays,n)'*H(delays,n)*X(n) ...
                + H(delays,n)'*W(delays));

        end

        B_ideal = rxSeq(X2,'QPSK');

        BER_ideal_tmp(t,idx) = ...
            sum(abs(B - B_ideal))/length(B);

    end

    %% Average BER
    BER_lmmse(idx) = mean(BER_lmmse_tmp(:,idx));
    BER_ls(idx) = mean(BER_ls_tmp(:,idx));
    BER_zf_dfe(idx) = mean(BER_zf_dfe_temp(:,idx));
    BER_lmmse_dfe(idx) = mean(BER_lmmse_dfe_temp(:,idx));
    BER_ideal(idx) = mean(BER_ideal_tmp(:,idx));

end

%% ================================================================
% PLOTS
% ================================================================
figure;

semilogy(SNR_dB,BER_lmmse,'-o','LineWidth',2);
hold on;
semilogy(SNR_dB,BER_ls,'-s','LineWidth',2);
semilogy(SNR_dB,BER_zf_dfe,'-d','LineWidth',2);
semilogy(SNR_dB,BER_lmmse_dfe,'-^','LineWidth',2);
semilogy(SNR_dB,BER_ideal,'-k','LineWidth',2);

grid on;

xlabel('SNR (dB)');
ylabel('BER');

legend('LMMSE', ...
       'Least Squares', ...
       'DFE-ZF', ...
       'DFE-LMMSE', ...
       'ISI-free');

ylim([1e-4 1]);
