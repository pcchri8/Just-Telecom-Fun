% Function to find the (S x K) sample window and
% set of K visible transmitted symbols

function [sampleWindow, includedSignals] = ...
    windowing(m,S,N,L)

left = floor((S-1)/2);
right = ceil((S-1)/2);

% Center window around symbol m
startIdx = max(1,m-left);
endIdx   = min(N+L-1,m+right);

sampleWindow = startIdx:endIdx;

% Find symbols contributing to these samples
includedSignals = [];

for k = 1:N

    symbolSamples = k:(k+L-1);

    if any(ismember(symbolSamples,sampleWindow))

        includedSignals = [includedSignals k];

    end
end

end